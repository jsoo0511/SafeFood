package com.ssafy.safefood.repo;

import java.util.List;

import com.ssafy.safefood.dto.Member;

public interface MemberDao {

	// 멤버 가입
	int insertMember(Member member);

	// 멤버 로그인 (멤버 정보 return)
	Member LoginMember(String id, String pw);

	// 멤버 search (로그인과 비슷해서 정리해야 함)
	Member searchMember(String id);

	// 멤버 정보 update
	int updateMember(Member member);

	// 멤버 정보 delete
	public int deleteMember(String id);

	// 멤버 리스트 찾아오기
	List<Member> searchAll();

	// 멤버가 먹은 음식 추가
	Member eatMember(String id);
	
	int deleteMyEat(String[] del);
}
