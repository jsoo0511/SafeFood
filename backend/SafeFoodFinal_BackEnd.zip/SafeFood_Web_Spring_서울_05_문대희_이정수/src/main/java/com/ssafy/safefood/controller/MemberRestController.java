//package com.ssafy.safefood.controller;
//
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.ssafy.safefood.dto.Eat;
//import com.ssafy.safefood.dto.Food;
//import com.ssafy.safefood.dto.FoodPageBean;
//import com.ssafy.safefood.dto.Member;
//import com.ssafy.safefood.service.FoodService;
//import com.ssafy.safefood.service.MemberService;
//
//import io.swagger.annotations.ApiOperation;
//import lombok.extern.slf4j.Slf4j;
//
//@RestController
//@Slf4j
//public class MemberRestController {
//	private String[] allergys = { "대두", "땅콩", "우유", "게", "새우", "참치", "연어", "쑥", "소고기", "닭고기", "돼지고기", "복숭아", "민들레",
//			"계란흰자" };
//
//	@Autowired
//	MemberService ms;
//
//	@Autowired
//	FoodService fs;
//
//	@Autowired
//	HttpSession session;
//// 로그인페이지
////	@GetMapping("member/login")
////	public String showLogin() {
////		return "member/login";
////	}
//
//// 로그인 처리
//	@GetMapping("/Login")
//	@ApiOperation("로그인+ 세션처리")
//	public ResponseEntity<Map<String, Object>> login(@RequestParam String id, @RequestParam String pw) {
//		try {
//			System.out.println(id + pw);
//			// 로그인 정보 확인 후 세션에 등록
//			Member result = ms.login(id, pw);
//
//			if (result != null) {//회원정보가 존재하면
//				session.setAttribute("login", result.getId());
//				
//				System.out.println("로그인 성공");
//
//				// 음식 목록 가져오기
//				//List<Food> list = fs.searchAll(new FoodPageBean());
//				//session.setAttribute("foodlist", list);
//				
//                return response("null",session.getAttribute("login"), HttpStatus.OK, true);
//				//return "redirect:../main";
//			} else {
//				//model.addAttribute("message", "ID / PW를 다시 확인해주세요");
//				return response("ID/PW를 다시 확인해주세요.","null",HttpStatus.CONFLICT,false);
//			}
//		} catch (RuntimeException e) {
//			e.printStackTrace();
//			//model.addAttribute("message", "LOGIN ERROR");
//			System.out.println("로그인 실패");
//			return response("로그인 실패.","null",HttpStatus.CONFLICT,false);
//		}
//	}
//
//// 정보수정 페이지
////	@GetMapping("member/modify")
////	public String showModify(Model model, HttpSession session) {
////		String loginuser = (String) session.getAttribute("login");
////		model.addAttribute("member", ms.searchMember(loginuser));
////		return "member/modify";
////	}
//
//// 회원가입 처리
//	@PostMapping("/Register")
//	@ApiOperation("회원가입")
//	public ResponseEntity<Map<String, Object>> memberRegist(@RequestParam String id,@RequestParam String pw, @RequestParam String name, @RequestParam String phone, @RequestParam String email,
//			@RequestParam("allergy") String[] allergy) {
//		try {
//
//			String allergySum = "";
//
//			if (allergy != null) {
//				for (String a : allergy) {
//					allergySum = allergySum.concat("/" + allergys[Integer.parseInt(a)]);
//				}
//			}
//
//			if (!allergySum.equals("")) {
//				allergySum = allergySum.substring(1);
//			}
//
//			System.out.println("/SignUp " + id + " / " + pw);
//			Member member = new Member(id, pw, name, phone, email, allergySum);
//
//		
//
//			return response(ms.signup(member),"null",HttpStatus.OK,true);
//		} catch (RuntimeException e) {
//			log.trace("error: {}",e);
//			return response("회원가입실패","null",HttpStatus.CONFLICT,false);
//		}
//	}
//
//// 회원가입 페이지
////	@GetMapping("member/signup")
////	public String showSignup() {
////		return "member/signup";
////	}
//
//// 로그아웃페이지
//	@GetMapping("/Logout")
//	@ApiOperation("로그아웃")
//	public ResponseEntity<Map<String, Object>> showLogout(/*HttpSession session*/) {
//		try {
//			session.invalidate();
//			return response("로그아웃성공","null",HttpStatus.OK,true);
//		} catch (RuntimeException e) {
//			log.trace("error: {}",e);
//			return response("로그아웃실패","null",HttpStatus.CONFLICT,false);
//		}
//// c:remove
//	}
//
//	@GetMapping("/SessionExistenceTest")
//	@ApiOperation("세션존재 유무테스트")
//	public ResponseEntity<Map<String, Object>> Exist(/*HttpSession session*/) {
//		try {
//		
//			return response(session.getAttribute("login"),"null",HttpStatus.OK,true);
//		} catch (RuntimeException e) {
//			log.trace("error: {}",e);
//			return response("세션존재","null",HttpStatus.CONFLICT,false);
//		}
//// c:remove
//	}
////// 멤버 리스트 페이지
////	@PostMapping("/member/list")
////	public String memberList() {
////		return "member/list";
////	}
//
//// 탈퇴처리
//	@DeleteMapping("withdraw")
//	@ApiOperation("회원탈퇴")
//	public ResponseEntity<Map<String, Object>> memberWithdraw(@RequestParam String id) {
//		try {
//			int result = ms.delete(id);
//			if(result==0)
//				throw new RuntimeException();
//			session.invalidate();
//			return response("회원탈퇴성공",session.getAttribute("login"),HttpStatus.OK,true);
//		} catch (RuntimeException e) {
//			log.trace("error: {}",e);
//			return response("회원탈퇴실패",session.getAttribute("login"),HttpStatus.CONFLICT,false);
//		}
//	}
//
//// 정보수정
//	@PutMapping("/Modify")
//	@ApiOperation("회원정보수정")
//	public ResponseEntity<Map<String, Object>> memberModify(@RequestParam String id,@RequestParam String pw, @RequestParam String name, @RequestParam String phone, @RequestParam String email,
//			@RequestParam("allergy") String[] allergy) {
//
//		try {		
//			String allergySum = "";
//			
//			if (allergy != null) {
//				for (String a : allergy) {
//					allergySum = allergySum.concat("/" + allergys[Integer.parseInt(a)]);
//				}
//			}
//			if (!allergySum.equals("")) {
//				allergySum = allergySum.substring(1);
//			}
//			
//			Member member = new Member(id, pw, name, phone, email, allergySum);
//			
//			int num = ms.update(member);
//			if(num==0)
//				throw new RuntimeException();
//			return response("수정성공",session.getAttribute("login"),HttpStatus.OK,true);
//			
//		} catch (RuntimeException e) {
//			return response("수정실패","null",HttpStatus.OK,true);
//		}
//	}
//
////// 음식 섭취 정보
////	@PostMapping("/member/eatinsert")
////	public String memberEatInsert() {
////		return "member/insert";
////	}
//
//// 음식 섭취 상세 정보
//	//@ResponseBody
//	@PostMapping("/AddEatList")
//	@ApiOperation("음식 섭취 정보 추가")
//	public ResponseEntity<Map<String, Object>> memberEatList(@RequestParam String foodname, /*@RequestParam String id,*/ @RequestParam int code,
//			@RequestParam int count, HttpSession session) {
//		String loginuser = (String) session.getAttribute("login");
//        int result=0;
//		if (loginuser != null) {
//			Eat temp = new Eat(0, loginuser, code, count, foodname);
//			result=fs.insertEat(temp);
//			return response(result,session.getAttribute("login"),HttpStatus.OK,true);
//		} else {
//			return response("로그인정보가 없습니다.","null",HttpStatus.CONFLICT,false);
//		}
//	}
//
//// 섭취 정보 삭제
//	@PostMapping("/deletemyeat")
//	public String deleteMyEat(HttpServletRequest req) {
//		String[] del = req.getParameterValues("del");
//
//		ms.deleteMyEat(del);
//
//		return "redirect:eatlist";
//	}
//	
//	private ResponseEntity<Map<String, Object>> response(Object data, Object loginSession, HttpStatus httpStatus, boolean status) {
//		Map<String, Object> resultMap = new HashMap<String, Object>();
//		resultMap.put("data", data);
//		resultMap.put("loginSession", loginSession);
//		resultMap.put("status", status);
//
//		// 상태와 함께 Map반환
//		return new ResponseEntity<>(resultMap, httpStatus);
//	}
//
//}
