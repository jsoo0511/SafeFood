package com.ssafy.safefood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Safefood문대희ApplicationTests {

	@Test
	void contextLoads() {
	}

}
